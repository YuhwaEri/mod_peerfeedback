-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_quiz`
--

DROP TABLE IF EXISTS `mdl_quiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_quiz` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `course` bigint(10) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `intro` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `introformat` smallint(4) NOT NULL DEFAULT '0',
  `timeopen` bigint(10) NOT NULL DEFAULT '0',
  `timeclose` bigint(10) NOT NULL DEFAULT '0',
  `timelimit` bigint(10) NOT NULL DEFAULT '0',
  `overduehandling` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'autoabandon',
  `graceperiod` bigint(10) NOT NULL DEFAULT '0',
  `preferredbehaviour` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `canredoquestions` smallint(4) NOT NULL DEFAULT '0',
  `attempts` mediumint(6) NOT NULL DEFAULT '0',
  `attemptonlast` smallint(4) NOT NULL DEFAULT '0',
  `grademethod` smallint(4) NOT NULL DEFAULT '1',
  `decimalpoints` smallint(4) NOT NULL DEFAULT '2',
  `questiondecimalpoints` smallint(4) NOT NULL DEFAULT '-1',
  `reviewattempt` mediumint(6) NOT NULL DEFAULT '0',
  `reviewcorrectness` mediumint(6) NOT NULL DEFAULT '0',
  `reviewmarks` mediumint(6) NOT NULL DEFAULT '0',
  `reviewspecificfeedback` mediumint(6) NOT NULL DEFAULT '0',
  `reviewgeneralfeedback` mediumint(6) NOT NULL DEFAULT '0',
  `reviewrightanswer` mediumint(6) NOT NULL DEFAULT '0',
  `reviewoverallfeedback` mediumint(6) NOT NULL DEFAULT '0',
  `questionsperpage` bigint(10) NOT NULL DEFAULT '0',
  `navmethod` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `shuffleanswers` smallint(4) NOT NULL DEFAULT '0',
  `sumgrades` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `grade` decimal(10,5) NOT NULL DEFAULT '0.00000',
  `timecreated` bigint(10) NOT NULL DEFAULT '0',
  `timemodified` bigint(10) NOT NULL DEFAULT '0',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `subnet` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `browsersecurity` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `delay1` bigint(10) NOT NULL DEFAULT '0',
  `delay2` bigint(10) NOT NULL DEFAULT '0',
  `showuserpicture` smallint(4) NOT NULL DEFAULT '0',
  `showblocks` smallint(4) NOT NULL DEFAULT '0',
  `completionattemptsexhausted` tinyint(1) DEFAULT '0',
  `completionpass` tinyint(1) DEFAULT '0',
  `allowofflineattempts` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_quiz_cou_ix` (`course`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='The settings for each quiz.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_quiz`
--

LOCK TABLES `mdl_quiz` WRITE;
/*!40000 ALTER TABLE `mdl_quiz` DISABLE KEYS */;
INSERT INTO `mdl_quiz` VALUES (1,4,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(9,14,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(11,14,'2018-Q3 Role Play Call #1','',1,0,0,0,'autosubmit',0,'immediatefeedback',0,0,0,1,0,-1,69888,69888,69888,69888,69888,69888,4352,1,'free',0,1.00000,10.00000,0,1537382650,'','','-',0,0,0,0,0,0,0),(12,1768,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(13,1773,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(14,1777,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1563908511,'','','-',0,0,0,0,0,0,0),(15,1789,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1563908511,'','','-',0,0,0,0,0,0,0),(16,1768,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(19,2548,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(20,2548,'RM MO Pre-course Quiz','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,3,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,0,'free',1,30.00000,30.00000,0,1522861487,'','','-',0,0,0,0,0,0,0),(22,2539,'SLP Finance Post-Test','',1,0,0,2400,'autosubmit',0,'deferredfeedback',0,1,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,15.00000,100.00000,0,1664425312,'','','-',0,0,0,0,0,0,0),(24,2539,'P3 Simulation Pre-Course Assessment','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,0,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,55.00000,10.00000,0,1663838208,'','','-',0,0,0,0,0,0,0),(25,2539,'SLP Finance Pre-Test','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,0,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,15.00000,10.00000,0,1663526911,'','','-',0,0,0,0,0,0,0),(26,2538,'SLP Finance Post-Test','',1,0,1668153600,2400,'autosubmit',0,'deferredfeedback',0,1,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,15.00000,100.00000,0,1667830013,'','','-',0,0,0,0,0,0,0),(28,2538,'SLP Finance Pre-Test','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,0,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,15.00000,10.00000,0,1665692403,'','','-',0,0,0,0,0,0,0),(30,2538,'7. P3 Simulation Pre-Course Assessment','',1,0,0,0,'autosubmit',0,'deferredfeedback',0,0,0,1,2,-1,69888,4352,4352,4352,4352,4352,4352,1,'free',1,55.00000,100.00000,0,1665602315,'','','-',0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `mdl_quiz` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:23:00
