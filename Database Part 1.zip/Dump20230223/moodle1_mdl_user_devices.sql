-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_user_devices`
--

DROP TABLE IF EXISTS `mdl_user_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_user_devices` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `userid` bigint(10) NOT NULL DEFAULT '0',
  `appid` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `platform` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pushid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `timecreated` bigint(10) NOT NULL,
  `timemodified` bigint(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_userdevi_pususe_uix` (`pushid`,`userid`),
  KEY `mdl_userdevi_uuiuse_ix` (`uuid`,`userid`),
  KEY `mdl_userdevi_use_ix` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='This table stores user''s mobile devices information in order';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_user_devices`
--

LOCK TABLES `mdl_user_devices` WRITE;
/*!40000 ALTER TABLE `mdl_user_devices` DISABLE KEYS */;
INSERT INTO `mdl_user_devices` VALUES (1,2,'com.moodle.moodlemobile','','SM-G955U1','Android','8.0.0','cSWK98Tj3AI:APA91bEoyYA4RAFHnyNF-mMvzMP4wdtXsElKdgDuMfZWTEIkX4BTOPcyi1c3WoJi4X8wul-UZRc6iTh2z_mpMFzMHAIwkWMG40YwlpkDr2z4uhEQ40Zx9upFNeF71zTY_WDsPaXVNcg_','cc87f8cf7d537c81',1523014046,1523014046),(2,197,'com.moodle.moodlemobile','Apple','iPhone10,2','iOS','12.0','11bd023f5ae6116ff61b8f1c726a289ea66b4e3e99306dca3eeccb5c82471d32','2B19361D-72E9-4A34-91C6-2721885C878E',1538762856,1538762856),(3,244,'com.moodle.moodlemobile','samsung','SM-G965U','Android','8.0.0','fANEKzKoPOQ:APA91bGz2bRkt3Ryhfrhnjh_mVYgwrO87j7wgWCUPJ3pyfAGsN7JYRgdQck1bXGfzewhnflRNnYFkIXViWh2mZWfrXDEiqYYuqD79mLumTPYBFjc2_s1weTesnyADMR0u_t-4Jyhtc-G','025ffec334ce77e3',1546987661,1546987661),(4,2,'com.moodle.moodlemobile','Xiaomi','Redmi 4A','Android','7.1.2','fBdRKDJyOI8:APA91bF8sfFwtsDSGuXvzf_k0eE3dloVQXGfse0bjqo-6DXSVpFYqMnshkQ0q2t9rftscUY2K_dAi814Dg5KS51bXCgCmaQOenWv1nl66rKsfA3YnINpxzbZtMGlGt_c2exU8_gdIalA','a29c3e881672feba',1548748463,1548828934),(5,2,'com.moodle.moodlemobile','LGE','Nexus 5','Android','6.0.1','fhlhQ9IiOHI:APA91bEx7-pJmTwhtpLOu3ntDYs2Jx6NGZWwjbAjtZQ6x_V-97c2TFtZPjexd0ZIe4USteVEqi2AFyqthCiJguwNDmaVPKUZt8kCuD3g01tqP5a-SLB8m99TpGcFpBMP4z1fxr2rUu4t','f8df5e642afaa3fd',1548761566,1548761566),(6,369,'com.moodle.moodlemobile','Xiaomi','Redmi 4A','Android','7.1.2','cW0Qr24YOWY:APA91bGN7V6XJBwplZThNEyHopgp3q1uvxBBQr1pbA3ABsNkl2iLcEqm5mIXonSPyHF2toYCjJHKoDLvhgzNUwI8-38WWCLP1Rfwf-wOxLtf01vGAi4Nz34M60PYxGn-AD5k0gg093Vx','a29c3e881672feba',1548829690,1548829690),(7,363,'com.moodle.moodlemobile','samsung','SM-G955U1','Android-fcm','8.0.0','cSWK98Tj3AI:APA91bEoyYA4RAFHnyNF-mMvzMP4wdtXsElKdgDuMfZWTEIkX4BTOPcyi1c3WoJi4X8wul-UZRc6iTh2z_mpMFzMHAIwkWMG40YwlpkDr2z4uhEQ40Zx9upFNeF71zTY_WDsPaXVNcg_','cc87f8cf7d537c81',1554248686,1554248686),(8,569,'com.moodle.moodlemobile','samsung','SM-G950F','Android-fcm','9','fIk2I8_TRN8:APA91bHW6YWkHwZq3evdhl3fQUss8d2fWSl45ydrrP0WDdNNW-wrD7_wY8LjF0JAiOXxCgnzBsgvVhWtJVZxD1RacXAF9FlHbi4KImXUvt5i3GjqSItkepVMHojEKbIT_XR2xgo9KeV3','9298191e783f81c4',1555536864,1555536864),(9,363,'com.moodle.moodlemobile','samsung','SM-T380','Android-fcm','8.1.0','c8UVrsQy_x0:APA91bENCts3uu-JIDooveDBu0ljDYNkbVhSpQJ9L4nASvGHMXq8PfgrHUU6tDwzyG7uDv0mODS6nwbaQ3ZYJR-dP_uqTqJrZ1E695SOuz9OT06VN7S-lZT9xlgEHPNnqFFd1oG-yEFM','cef070891eed50f9',1556608419,1556608419),(10,682,'com.moodle.moodlemobile','Apple','iPhone10,1','iOS-fcm','12.2','eicosmOQJGQ:APA91bHJBDpa6rzY06GJmjR5Ize3ajzzZfqsixn3SLZBCPnXgp2Zl-cpgKX4MPmrjedI8QsX1a2gJV8lEZInxSPhQJPJpm33HaC30SNBZAN9VJHtlJNMFy-kgu1YC4dxx69TxoQLVlc3','0342AF31-FB13-400D-8196-C5A766493D6F',1557098768,1557098768),(11,363,'com.moodle.moodlemobile','samsung','SM-G955U1','Android-fcm','9','czIYSoNaPxw:APA91bHO0y6MeRZwyUCcU6fCkpH5y7frVqPBMroi9Hq3XoJqe1na-5xlfxMKf9LbnHwWJEF4gbOgcEim7eme8NuW1JrJTf2QEOmzZVmfekSJ8gCRD71V0rfMuGNPkEmFQTIt2p8BTAeL','34a5286168fe14b5',1557757805,1557757805),(12,1042,'com.moodle.moodlemobile','Apple','iPhone7,2','iOS-fcm','12.2','fvBrBCVWIGc:APA91bEp60H05EYeQPDnDz9wPCj7zhNnMBWWKb_h3A9FKR-g-xlsFTh6unLRkiR6Rhj2ru_dhmH0wlIRtFgP0fA4tQNOfc6SGEgdW4L9b8OfVwBOx0DleRWboBoOORKRF3ioLo5iqtEG','8D76D520-4FFD-4012-B510-64C08A8E0C52',1567524823,1567524823),(13,1043,'com.moodle.moodlemobile','Apple','iPhone10,4','iOS-fcm','12.4.1','f_kwtpwKV7o:APA91bE-JSsFM8aHzS7oJQq5B-HT9XPyNbgiDSQjxusOP0f6c-4Aegvyz3njt1W7Z6L7RwMNtuOnuWaLIJ19C6DGjZeeJfr0ZaukGT5VU3AhS5-NVtcp1i9TCHmtGUxIM0e6tX5G-JSw','28324761-9EBD-4988-A486-0653E58EF96C',1568765588,1568765588),(14,363,'com.moodle.moodlemobile','rockchip','PX5','Android-fcm','9','fgfo5KWhrNA:APA91bGj7ZNs4OaO_TkRQ0880maT0cKQKOSaQhM390hq3l8l6HPZOqTW2XoSl38ZS0AkMffWCUQjk8Ew4YngUnMfuYndhgmM9vw4LlPAKJ3cLGj0UKas9B2rMRuXK1RUTdZPC6kjBTe8','c9998a2d245f5b8b',1577312819,1577312819),(15,1616,'com.moodle.moodlemobile','Apple','iPhone10,3','iOS-fcm','13.3.1','dMiR-8ljJLE:APA91bEbInBCAlZ2CgduUc5CrytPoEnsS5inZbhaKCZHDwecbqIGq6XUogCsWJwD8T9mTShUbnQQpQclP5K6AJSLL2gzCLv81VDCI53VZOkLbgabNVJWX1B8Tm5bki_h-TrRE92abqqI','BA302BA3-B8A1-41BB-8F2D-E77EBEA4161B',1581167148,1581167148),(16,1604,'com.moodle.moodlemobile','Apple','iPhone10,5','iOS-fcm','13.3.1','d1jY-Z24euk:APA91bFaeTapBya7Qlu-nGLRtg2OdVn3bClNIgaUhuor6vsyMzWFIBviWTdPvILawHKLGzq4VE5KdkkckEwvWEeoeXPE650vXEzNfAoTisxwABgnuTNeCpsLnlmHjFD5ax6RHPH8zTkE','5E11D946-2443-4F2F-A416-B7BC96295E7C',1581214223,1581214223),(17,1604,'com.moodle.moodlemobile','Apple','iPad6,8','iOS-fcm','13.3.1','eLhWyAHQkK4:APA91bHP9kI-qs6u2Q7zd8CMpBtg98Hk9nrIlN3UkjyxN-UQ-i5XYs2NW8xodTdvCaRAjgOxGSbRkNVMvM-RWa_WjTQTJNvwnQW1CVaqShirmfMfzbhF4I7HTV8zDz-IGB38ZjOKD-rE','225851F0-0661-4775-817D-8A8299F604EA',1581248598,1581248598),(18,1608,'com.moodle.moodlemobile','samsung','SM-G973F','Android-fcm','9','dyzU6aHBmUk:APA91bFeBvFZcrYTuRquANXmm9gouqzvrWIf4DqImau1tMO_iblyjEZdD1EfUk2P8-6dcFzlfxWIMWkyI-9DYOArkFF5ZBIKZXF_TtM9RSGbfb1Bfvt7z7Qbski4952WAt6EYNBuoog3','91d0a7f76612af49',1581338560,1581338560),(19,1605,'com.moodle.moodlemobile','Apple','iPhone11,2','iOS-fcm','13.3.1','f_3QAEPFPEY:APA91bEWqjDdf_4ZF3EIXIiO1a1JIBubkdTWinCCuShQ_p-Eqb9tFRnGYluHNpQhUaPOPMvYIU7kCk-VZQsbGyPuGH6Eo7FPts4GiaUVQKrYklqNSO57KN-JvzlGK5805x4ZReOePFHY','BEC22E87-A122-492E-A87C-AE34FC9166CE',1581367892,1581367892),(20,1624,'com.moodle.moodlemobile','Apple','iPhone12,3','iOS-fcm','13.3.1','d1QXepG8eS0:APA91bHtK7LnThJP3_JsYYBCCqMvn-w-S8y75htQkZLfGjutSFQh-si_SM_PKW4smuPLAU7SarsK2AvSG5sp-KCAw9lB188dcx5EOc3c4-WtRXXTJjJGYda53w1L4Se8f7qdKhei4PQw','21BFAC10-C961-4214-9EB7-54A2F18CC2DD',1581613131,1581613131),(21,1598,'com.moodle.moodlemobile','samsung','SM-G950U','Android-fcm','9','chyAwiHN-Fs:APA91bEf64JnT_BS4OWvDRb9FFlpsKdWStK_flFWCjUZD1u_qMXWFGIQKv-6ZaetJAIZDONfWFN65RR0xiRvvoyxFpYvCBTe2ba2p5f8Oi3gPYcmr85TJalg2jQVDmAB958XEGtOj4N6','84a8a8a0eb46d33e',1582759452,1582759452),(22,1614,'com.moodle.moodlemobile','HUAWEI','ANE-LX1','Android-fcm','9','eztjB2O-Xec:APA91bFm0MxF0wGVxh22578gNGRJw1Paywi-o3RIynGCXUdM48wuzMKXPXwUjzVPoQeiTvMAiOrsaY-oS43rWJMloVKrKTxYhAeiCiQxhzdUIGNTrLNzpfID7x8m1-brDWTY5UM-Owgh','10172fc461b0e6ae',1583092762,1583092762),(23,1917,'com.moodle.moodlemobile','Apple','iPhone11,6','iOS-fcm','13.6','f43Repsi2eA:APA91bGJN2kMujCuMq_Ml7bCx86KY1U-3T-dAXhuU-Mv6EgrIT6D1YbT5XHiaP35fsGzkAYifabvxgQCUXAfAiCqxWbRg6X5eNkyU7_kNI2oIFlHDEcq8t2focn1N6BXTJH7aYQReZzl','28E3DD52-8499-45CC-ACE7-B1992581C18E',1597235338,1597235338),(24,2332,'com.moodle.moodlemobile','samsung','SM-G930F','Android-fcm','8.0.0','dFlvLRPQ2oE:APA91bGL31vUmhY_0AuRxikmg4NS13LRfRN3dTjLW_EOooEPOn7Cev5NQd0uBDWAlXDwhcG8JG5K8bKnm_nQjv1zfhD9qmRMN2Cc3Tm5kvqzKyEAXEjLU8cUyDztsYQSlZGqnY46MIgQ','d3fddfb4e92e6ba7',1617109077,1617109077);
/*!40000 ALTER TABLE `mdl_user_devices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:22:40
