-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_scorm_scoes_data`
--

DROP TABLE IF EXISTS `mdl_scorm_scoes_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_scorm_scoes_data` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `scoid` bigint(10) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mdl_scorscoedata_sco_ix` (`scoid`)
) ENGINE=InnoDB AUTO_INCREMENT=439 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='Contains variable data get from packages';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_scorm_scoes_data`
--

LOCK TABLES `mdl_scorm_scoes_data` WRITE;
/*!40000 ALTER TABLE `mdl_scorm_scoes_data` DISABLE KEYS */;
INSERT INTO `mdl_scorm_scoes_data` VALUES (1,2,'isvisible','true'),(2,2,'parameters',''),(3,4,'isvisible','true'),(4,4,'parameters',''),(5,6,'isvisible','true'),(6,6,'parameters',''),(15,8,'isvisible','true'),(16,8,'parameters',''),(21,14,'isvisible','true'),(22,14,'parameters',''),(23,16,'isvisible','true'),(24,16,'parameters',''),(25,18,'isvisible','true'),(26,18,'parameters',''),(31,24,'isvisible','true'),(32,24,'parameters',''),(33,26,'isvisible','true'),(34,26,'parameters',''),(40,30,'parameters',''),(41,30,'max_time_allowed',''),(42,30,'time_limit_action',''),(43,30,'mastery_score',''),(44,30,'datafromlms','iSpring Flip'),(45,32,'parameters',''),(46,32,'max_time_allowed',''),(47,32,'time_limit_action',''),(48,32,'mastery_score',''),(49,32,'datafromlms','iSpring Flip'),(55,36,'parameters',''),(56,36,'max_time_allowed',''),(57,36,'time_limit_action',''),(58,36,'mastery_score',''),(59,36,'datafromlms','iSpring Flip'),(60,33,'parameters',''),(61,33,'max_time_allowed',''),(62,33,'time_limit_action',''),(63,33,'mastery_score',''),(64,33,'datafromlms','iSpring Quizmaker'),(65,38,'parameters',''),(66,38,'max_time_allowed',''),(67,38,'time_limit_action',''),(68,38,'mastery_score',''),(69,38,'datafromlms','iSpring Flip'),(70,40,'parameters',''),(71,40,'max_time_allowed',''),(72,40,'time_limit_action',''),(73,40,'mastery_score',''),(74,40,'datafromlms','iSpring Quizmaker'),(75,42,'parameters',''),(76,42,'max_time_allowed',''),(77,42,'time_limit_action',''),(78,42,'mastery_score',''),(79,42,'datafromlms','iSpring Flip'),(80,45,'isvisible','true'),(81,45,'parameters',''),(84,48,'parameters',''),(85,48,'max_time_allowed',''),(86,48,'time_limit_action',''),(87,48,'mastery_score',''),(88,48,'datafromlms','iSpring Flip'),(89,50,'parameters',''),(90,50,'max_time_allowed',''),(91,50,'time_limit_action',''),(92,50,'mastery_score',''),(93,50,'datafromlms','iSpring Quizmaker'),(104,56,'parameters',''),(105,56,'max_time_allowed',''),(106,56,'time_limit_action',''),(107,56,'mastery_score',''),(108,56,'datafromlms','iSpring Flip'),(109,58,'parameters',''),(110,58,'max_time_allowed',''),(111,58,'time_limit_action',''),(112,58,'mastery_score',''),(113,58,'datafromlms','iSpring Quizmaker'),(114,60,'parameters',''),(115,60,'max_time_allowed',''),(116,60,'time_limit_action',''),(117,60,'mastery_score',''),(118,60,'datafromlms','iSpring Flip'),(119,63,'isvisible','true'),(120,63,'parameters',''),(121,64,'parameters',''),(122,64,'max_time_allowed',''),(123,64,'time_limit_action',''),(124,64,'mastery_score',''),(125,64,'datafromlms','iSpring Flip'),(126,66,'parameters',''),(127,66,'max_time_allowed',''),(128,66,'time_limit_action',''),(129,66,'mastery_score',''),(130,66,'datafromlms','iSpring Quizmaker'),(131,68,'parameters',''),(132,68,'max_time_allowed',''),(133,68,'time_limit_action',''),(134,68,'mastery_score',''),(135,68,'datafromlms','iSpring Flip'),(136,71,'isvisible','true'),(137,71,'parameters',''),(138,72,'parameters',''),(139,72,'max_time_allowed',''),(140,72,'time_limit_action',''),(141,72,'mastery_score',''),(142,72,'datafromlms','iSpring Flip'),(143,74,'parameters',''),(144,74,'max_time_allowed',''),(145,74,'time_limit_action',''),(146,74,'mastery_score',''),(147,74,'datafromlms','iSpring Quizmaker'),(148,77,'isvisible','true'),(149,77,'parameters',''),(154,83,'isvisible','true'),(155,83,'parameters',''),(156,85,'isvisible','true'),(157,85,'parameters',''),(158,87,'isvisible','true'),(159,87,'parameters',''),(160,89,'isvisible','true'),(161,89,'parameters',''),(162,91,'isvisible','true'),(163,91,'parameters',''),(164,93,'isvisible','true'),(165,93,'parameters',''),(166,94,'parameters',''),(167,94,'max_time_allowed',''),(168,94,'time_limit_action',''),(169,94,'mastery_score',''),(170,94,'datafromlms','iSpring Flip'),(171,96,'parameters',''),(172,96,'max_time_allowed',''),(173,96,'time_limit_action',''),(174,96,'mastery_score',''),(175,96,'datafromlms','iSpring Quizmaker'),(181,100,'parameters',''),(182,100,'max_time_allowed',''),(183,100,'time_limit_action',''),(184,100,'mastery_score',''),(185,100,'datafromlms','iSpring Quizmaker'),(188,103,'isvisible','true'),(189,103,'parameters',''),(192,107,'isvisible','true'),(193,107,'parameters',''),(196,109,'isvisible','true'),(197,109,'parameters',''),(198,112,'isvisible','true'),(199,112,'parameters',''),(207,118,'isvisible','true'),(208,118,'parameters',''),(209,119,'parameters',''),(210,119,'max_time_allowed',''),(211,119,'time_limit_action',''),(212,119,'mastery_score',''),(213,119,'datafromlms','iSpring Flip'),(214,122,'isvisible','true'),(215,122,'parameters',''),(261,148,'isvisible','true'),(262,148,'parameters',''),(269,156,'isvisible','true'),(270,156,'parameters',''),(271,158,'isvisible','true'),(272,158,'parameters',''),(287,160,'isvisible','true'),(288,160,'parameters',''),(289,142,'isvisible','true'),(290,142,'parameters',''),(291,140,'isvisible','true'),(292,140,'parameters',''),(293,162,'isvisible','true'),(294,162,'parameters',''),(295,164,'isvisible','true'),(296,164,'parameters',''),(297,166,'isvisible','true'),(298,166,'parameters',''),(305,168,'isvisible','true'),(306,168,'parameters',''),(307,175,'isvisible','true'),(308,175,'parameters',''),(309,172,'isvisible','true'),(310,172,'parameters',''),(311,178,'isvisible','true'),(312,178,'parameters',''),(313,180,'isvisible','true'),(314,180,'parameters',''),(315,182,'isvisible','true'),(316,182,'parameters',''),(317,184,'isvisible','true'),(318,184,'parameters',''),(319,186,'isvisible','true'),(320,186,'parameters',''),(327,188,'isvisible','true'),(328,188,'parameters',''),(329,191,'isvisible','true'),(330,191,'parameters',''),(333,195,'isvisible','true'),(334,195,'parameters',''),(335,197,'isvisible','true'),(336,197,'parameters',''),(337,199,'isvisible','true'),(338,199,'parameters',''),(339,201,'isvisible','true'),(340,201,'parameters',''),(343,203,'isvisible','true'),(344,203,'parameters',''),(347,208,'isvisible','true'),(348,208,'parameters',''),(349,210,'isvisible','true'),(350,210,'parameters',''),(355,216,'isvisible','true'),(356,216,'parameters',''),(365,226,'isvisible','true'),(366,226,'parameters',''),(373,234,'isvisible','true'),(374,234,'parameters',''),(375,236,'isvisible','true'),(376,236,'parameters',''),(379,240,'isvisible','true'),(380,240,'parameters',''),(381,242,'isvisible','true'),(382,242,'parameters',''),(387,244,'isvisible','true'),(388,244,'parameters',''),(389,246,'isvisible','true'),(390,246,'parameters',''),(395,252,'isvisible','true'),(396,252,'parameters',''),(397,254,'isvisible','true'),(398,254,'parameters',''),(399,256,'isvisible','true'),(400,256,'parameters',''),(401,258,'isvisible','true'),(402,258,'parameters',''),(403,260,'isvisible','true'),(404,260,'parameters',''),(405,238,'isvisible','true'),(406,238,'parameters',''),(419,274,'isvisible','true'),(420,274,'parameters',''),(421,276,'isvisible','true'),(422,276,'parameters',''),(425,280,'isvisible','true'),(426,280,'parameters',''),(427,282,'isvisible','true'),(428,282,'parameters',''),(429,284,'isvisible','true'),(430,284,'parameters',''),(431,286,'isvisible','true'),(432,286,'parameters',''),(433,288,'isvisible','true'),(434,288,'parameters',''),(435,290,'isvisible','true'),(436,290,'parameters',''),(437,292,'isvisible','true'),(438,292,'parameters','');
/*!40000 ALTER TABLE `mdl_scorm_scoes_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:24:45
