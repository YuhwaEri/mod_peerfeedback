-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_task_scheduled`
--

DROP TABLE IF EXISTS `mdl_task_scheduled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_task_scheduled` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `component` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `classname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastruntime` bigint(10) DEFAULT NULL,
  `nextruntime` bigint(10) DEFAULT NULL,
  `blocking` tinyint(2) NOT NULL DEFAULT '0',
  `minute` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hour` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `day` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `month` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `dayofweek` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `faildelay` bigint(10) DEFAULT NULL,
  `customised` tinyint(2) NOT NULL DEFAULT '0',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_tasksche_cla_uix` (`classname`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='List of scheduled tasks to be run by cron.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_task_scheduled`
--

LOCK TABLES `mdl_task_scheduled` WRITE;
/*!40000 ALTER TABLE `mdl_task_scheduled` DISABLE KEYS */;
INSERT INTO `mdl_task_scheduled` VALUES (1,'moodle','\\core\\task\\session_cleanup_task',1677201662,1677201720,0,'*','*','*','*','*',0,0,0),(2,'moodle','\\core\\task\\delete_unconfirmed_users_task',1677200461,1677204000,0,'0','*','*','*','*',0,0,0),(3,'moodle','\\core\\task\\delete_incomplete_users_task',1677200761,1677204300,0,'5','*','*','*','*',0,0,0),(4,'moodle','\\core\\task\\backup_cleanup_task',1677201061,1677204600,0,'10','*','*','*','*',0,0,0),(5,'moodle','\\core\\task\\tag_cron_task',1677150361,1677236760,0,'6','3','*','*','*',0,0,0),(6,'moodle','\\core\\task\\context_cleanup_task',1677198362,1677201900,0,'25','*','*','*','*',0,0,0),(7,'moodle','\\core\\task\\cache_cleanup_task',1677198661,1677202200,0,'30','*','*','*','*',0,0,0),(8,'moodle','\\core\\task\\messaging_cleanup_task',1677198964,1677202500,0,'35','*','*','*','*',0,0,0),(9,'moodle','\\core\\task\\send_new_user_passwords_task',1677201662,1677201720,0,'*','*','*','*','*',0,0,0),(10,'moodle','\\core\\task\\send_failed_login_notifications_task',1677201662,1677201720,0,'*','*','*','*','*',0,0,0),(11,'moodle','\\core\\task\\create_contexts_task',1677139262,1677225600,1,'0','0','*','*','*',0,0,0),(12,'moodle','\\core\\task\\legacy_plugin_cron_task',1677201663,1677201720,0,'*','*','*','*','*',0,0,0),(13,'moodle','\\core\\task\\grade_cron_task',1677201663,1677201720,0,'*','*','*','*','*',0,0,0),(14,'moodle','\\core\\task\\events_cron_task',1677201663,1677201720,0,'*','*','*','*','*',0,0,0),(15,'moodle','\\core\\task\\completion_regular_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(16,'moodle','\\core\\task\\completion_daily_task',1677118562,1677204840,0,'14','18','*','*','*',0,0,0),(17,'moodle','\\core\\task\\portfolio_cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(18,'moodle','\\core\\task\\plagiarism_cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(19,'moodle','\\core\\task\\calendar_cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(20,'moodle','\\core\\task\\blog_cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(21,'moodle','\\core\\task\\question_cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(22,'moodle','\\core\\task\\registration_cron_task',1642721162,1677261665,0,'9','15','*','*','4',86400,0,0),(23,'moodle','\\core\\task\\check_for_updates_task',1677196861,1677204000,0,'0','*/2','*','*','*',0,0,0),(24,'moodle','\\core\\task\\cache_cron_task',1677199862,1677203400,0,'50','*','*','*','*',0,0,0),(25,'moodle','\\core\\task\\automated_backup_task',1677199863,1677203400,0,'50','*','*','*','*',0,0,0),(26,'moodle','\\core\\task\\badges_cron_task',1677201664,1677201900,0,'*/5','*','*','*','*',0,0,0),(27,'moodle','\\core\\task\\file_temp_cleanup_task',1677185761,1677207300,0,'55','*/6','*','*','*',0,0,0),(28,'moodle','\\core\\task\\file_trash_cleanup_task',1677185762,1677207300,0,'55','*/6','*','*','*',0,0,0),(29,'moodle','\\core\\task\\search_index_task',1677200461,1677202200,0,'*/30','*','*','*','*',0,0,0),(30,'moodle','\\core\\task\\search_optimize_task',1677183361,1677226500,0,'15','*/12','*','*','*',0,0,0),(31,'moodle','\\core\\task\\stats_cron_task',1677139262,1677225600,0,'0','0','*','*','*',0,0,0),(32,'moodle','\\core\\task\\password_reset_cleanup_task',1677182462,1677204000,0,'0','*/6','*','*','*',0,0,0),(33,'moodle','\\core\\task\\complete_plans_task',1677201361,1677204840,0,'14','*','*','*','*',0,0,0),(34,'moodle','\\core\\task\\sync_plans_from_template_cohorts_task',1677200461,1677204060,0,'1','*','*','*','*',0,0,0),(35,'moodle','\\core_files\\task\\conversion_cleanup_task',1677146761,1677232920,0,'2','2','*','*','*',0,0,0),(36,'moodle','\\core\\oauth2\\refresh_system_tokens_task',1677198661,1677202200,0,'30','*','*','*','*',0,0,0),(37,'moodle','\\core\\task\\analytics_cleanup_task',1677199561,1677202920,0,'42','*','*','*','*',0,0,0),(38,'mod_forum','\\mod_forum\\task\\cron_task',1677201664,1677201720,0,'*','*','*','*','*',0,0,0),(39,'mod_scorm','\\mod_scorm\\task\\cron_task',1677201665,1677201900,0,'*/5','*','*','*','*',0,0,0),(40,'auth_cas','\\auth_cas\\task\\sync_task',0,1527922800,0,'0','0','*','*','*',0,0,1),(41,'auth_db','\\auth_db\\task\\sync_users',0,1527858660,0,'11','6','*','*','*',0,0,1),(42,'auth_ldap','\\auth_ldap\\task\\sync_roles',0,1527922800,0,'0','0','*','*','*',0,0,1),(43,'auth_ldap','\\auth_ldap\\task\\sync_task',0,1527922800,0,'0','0','*','*','*',0,0,1),(44,'enrol_flatfile','\\enrol_flatfile\\task\\flatfile_sync_task',1677201361,1677204900,0,'15','*','*','*','*',0,0,0),(45,'enrol_imsenterprise','\\enrol_imsenterprise\\task\\cron_task',0,1527840600,0,'10','*','*','*','*',0,0,0),(46,'enrol_ldap','\\enrol_ldap\\task\\sync_enrolments',0,1527841260,0,'21','1','*','*','*',0,0,1),(47,'enrol_lti','\\enrol_lti\\task\\sync_grades',1528715146,1528716600,0,'*/30','*','*','*','*',0,0,0),(48,'enrol_lti','\\enrol_lti\\task\\sync_members',1528715146,1528716600,0,'*/30','*','*','*','*',0,0,0),(49,'editor_atto','\\editor_atto\\task\\autosave_cleanup_task',1676618161,1677222900,0,'15','23','*','*','4',0,0,0),(50,'repository_onedrive','\\repository_onedrive\\remove_temp_access_task',0,1528326960,0,'16','16','*','*','3',0,0,0),(51,'tool_analytics','\\tool_analytics\\task\\train_models',1677168061,1677254400,0,'0','8','*','*','*',0,0,0),(52,'tool_analytics','\\tool_analytics\\task\\predict_models',1677193262,1677279600,0,'0','15','*','*','*',0,0,0),(53,'tool_cohortroles','\\tool_cohortroles\\task\\cohort_role_sync',1677201661,1677205080,0,'18','*','*','*','*',0,0,0),(54,'tool_langimport','\\tool_langimport\\task\\update_langpacks_task',1556623267,1556709420,0,'17','4','*','*','*',0,1,1),(55,'tool_messageinbound','\\tool_messageinbound\\task\\pickup_task',1556644564,1556644620,0,'*','*','*','*','*',0,1,1),(56,'tool_messageinbound','\\tool_messageinbound\\task\\cleanup_task',1556614564,1556700900,0,'55','1','*','*','*',0,1,1),(57,'tool_monitor','\\tool_monitor\\task\\clean_events',1677201665,1677201720,0,'*','*','*','*','*',0,0,0),(58,'tool_monitor','\\tool_monitor\\task\\check_subscriptions',1677153961,1677240120,0,'2','4','*','*','*',0,0,0),(59,'tool_recyclebin','\\tool_recyclebin\\task\\cleanup_course_bin',1677200461,1677202200,0,'*/30','*','*','*','*',0,0,0),(60,'tool_recyclebin','\\tool_recyclebin\\task\\cleanup_category_bin',1677200461,1677202200,0,'*/30','*','*','*','*',0,0,0),(61,'assignfeedback_editpdf','\\assignfeedback_editpdf\\task\\convert_submissions',0,1677272762,0,'*/15','*','*','*','*',86400,0,0),(62,'logstore_legacy','\\logstore_legacy\\task\\cleanup_task',0,1527855720,0,'22','5','*','*','*',0,0,0),(63,'logstore_standard','\\logstore_standard\\task\\cleanup_task',1677153962,1677240120,0,'2','4','*','*','*',0,0,0),(64,'mod_customcert','\\mod_customcert\\task\\email_certificate_task',1677201665,1677201720,0,'*','*','*','*','*',0,0,0),(65,'mod_zoom','\\mod_zoom\\task\\update_meetings',1677155461,1677241800,0,'30','4','*','*','*',0,0,0),(66,'enrol_category','\\enrol_category\\task\\enrol_category_sync',0,1527837600,0,'*','*','*','*','*',0,0,0),(67,'enrol_cohort','\\enrol_cohort\\task\\enrol_cohort_sync',1677201361,1677204900,0,'15','*','*','*','*',0,0,0),(68,'enrol_manual','\\enrol_manual\\task\\sync_enrolments',1677201661,1677202200,0,'*/10','*','*','*','*',0,0,0),(69,'enrol_manual','\\enrol_manual\\task\\send_expiry_notifications',1677201661,1677202200,0,'*/10','*','*','*','*',0,0,0),(70,'enrol_meta','\\enrol_meta\\task\\enrol_meta_sync',0,1527840360,0,'6','*','*','*','*',0,0,0),(71,'enrol_paypal','\\enrol_paypal\\task\\process_expirations',0,1527837600,0,'*','*','*','*','*',0,0,0),(72,'enrol_self','\\enrol_self\\task\\sync_enrolments',1677201662,1677202200,0,'*/10','*','*','*','*',0,0,0),(73,'enrol_self','\\enrol_self\\task\\send_expiry_notifications',1556644263,1556644800,0,'*/10','*','*','*','*',0,1,1),(74,'tool_dataprivacy','\\tool_dataprivacy\\task\\expired_retention_period',1677117661,1677204000,0,'0','18','*','*','*',0,0,0),(75,'tool_dataprivacy','\\tool_dataprivacy\\task\\delete_expired_contexts',1677139262,1677225600,0,'0','0','*','*','*',0,0,0),(76,'ltiservice_gradebookservices','\\ltiservice_gradebookservices\\task\\cleanup_task',1677150361,1677236580,0,'3','3','*','*','*',0,0,0),(77,'mod_zoom','\\mod_zoom\\task\\get_meeting_reports',0,1677227761,0,'0','*/6','*','*','*',86400,0,0),(78,'mod_zoom','\\mod_zoom\\task\\update_tracking_fields',1677182462,1677204000,0,'0','*/6','*','*','*',0,0,0),(79,'mod_zoom','\\mod_zoom\\task\\get_meeting_recordings',1677193262,1677204000,0,'0','*/3','*','*','*',0,0,0),(80,'mod_zoom','\\mod_zoom\\task\\delete_meeting_recordings',1677139262,1677225600,0,'0','0','*','*','*',0,0,0);
/*!40000 ALTER TABLE `mdl_task_scheduled` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:23:07
