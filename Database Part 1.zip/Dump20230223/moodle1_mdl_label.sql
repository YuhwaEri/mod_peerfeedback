-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_label`
--

DROP TABLE IF EXISTS `mdl_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_label` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `course` bigint(10) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `intro` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `introformat` smallint(4) DEFAULT '0',
  `timemodified` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `mdl_labe_cou_ix` (`course`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='Defines labels';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_label`
--

LOCK TABLES `mdl_label` WRITE;
/*!40000 ALTER TABLE `mdl_label` DISABLE KEYS */;
INSERT INTO `mdl_label` VALUES (1,2498,'Zoom Recordings','Zoom Recordings',1,1603127749),(2,2499,'Zoom Recordings','<p>Zoom Recordings</p>',1,1603494411),(3,2500,'Zoom Recordings','<p>Zoom Recordings</p>',1,1604426339),(4,2509,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(5,2510,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(7,2512,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(8,2519,'Zoom Links','<h4><b><span class=\"\" style=\"color: rgb(125, 159, 211);\">Zoom Links</span></b></h4>',1,1628628800),(9,2524,'Zoom Recordings','Zoom Recordings',1,1603127749),(11,2527,'Zoom Recordings','Zoom Recordings',1,1603127749),(12,2528,'Zoom Recordings','Zoom Recordings',1,1603127749),(15,2531,'Zoom Recordings','Zoom Recordings',1,1603127749),(18,2535,'Zoom Recordings','Zoom Recordings',1,1603127749),(19,2543,'Zoom Links','<h4><b><span class=\"\" style=\"color: rgb(125, 159, 211);\">Zoom Links</span></b></h4>',1,1628628800),(20,2545,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(21,2549,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(22,2550,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(23,2552,'Reading Materials','<p><b><u>Reading Materials</u></b></p>',1,1614835271),(24,2538,'Role Play Timing (EDT)14:00 - 14:15	CTC Teams14:20...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT)</b></p><p>14:00 - 14:15<span style=\"white-space:pre\">	</span>CTC Teams<br>14:20 - 14:35<span style=\"white-space:pre\">	</span>EPC Teams<br>14:40 - 14:55<span style=\"white-space:pre\">	</span>IPC Teams<br>15:00 - 15:15<span style=\"white-space:pre\">	</span>MPC Teams<br>15:20 - 15:35<span style=\"white-space:pre\">	</span>PTC Teams</p><p><br></p>',1,1666460164),(25,2538,'Role Play Timing (EDT)14:00 - 14:15	EPC Teams14:20...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT)</b></p><p>14:00 - 14:15<span style=\"white-space:pre\">	</span>EPC Teams<br>14:20 - 14:35<span style=\"white-space:pre\">	</span>IPC Teams<br>14:40 - 14:55<span style=\"white-space:pre\">	</span>MPC Teams<br>15:00 - 15:15<span style=\"white-space:pre\">	</span>PTC Teams<br>15:20 - 15:35<span style=\"white-space:pre\">	</span>CTC Teams</p><p><br></p>',1,1666660427),(26,2538,'Role Play Timing (EDT) - 10 Minutes14:30 - 14:40	I...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT) - 10 Minutes</b></p><p>14:30 - 14:40<span style=\"white-space:pre\">	</span>IPC Teams<br>14:45 - 14:55<span style=\"white-space:pre\">	</span>MPC Teams<br>15:00 - 15:10<span style=\"white-space:pre\">	</span>PTC Teams<br>15:15 - 15:25<span style=\"white-space:pre\">	</span>CTC Teams<br>15:30 - 15:40<span style=\"white-space:pre\">	</span>EPC Teams</p><p><br></p>',1,1666889896),(27,2538,'Role Play Timing (EDT) - 10 Minutes14:30 - 14:40	M...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT) - 10 Minutes</b></p><p>14:30 - 14:40<span style=\"white-space:pre\">	</span>MPC Teams<br>14:45 - 14:55<span style=\"white-space:pre\">	</span>PTC Teams<br>15:00 - 15:10<span style=\"white-space:pre\">	</span>CTC Teams<br>15:15 - 15:25<span style=\"white-space:pre\">	</span>EPC Teams<br>15:30 - 15:40<span style=\"white-space:pre\">	</span>IPC Teams</p><p><br></p>',1,1667235651),(28,2538,'Role Play Timing (EDT) - 10 Minutes13:30 - 13:40	P...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT) - 10 Minutes</b></p><p>13:30 - 13:40<span style=\"white-space:pre\">	</span>PTC Teams<br>13:45 - 13:55<span style=\"white-space:pre\">	</span>CTC Teams<br>14:00 - 14:10<span style=\"white-space:pre\">	</span>EPC Teams<br>14:15 - 14:25<span style=\"white-space:pre\">	</span>IPC Teams<br>14:30 - 14:40<span style=\"white-space:pre\">	</span>MPC Teams</p><p><br></p>',1,1667323735),(29,2538,'Role Play Timing (EDT) - 5 Minutes14:00 - 14:05	CT...','<p><b style=\"color: rgb(85, 85, 85); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 1.23rem;\">Role Play Timing (EDT) - 5 Minutes</b></p><p>14:00 - 14:05<span style=\"white-space:pre\">	</span>CTC Teams<br>14:10 - 14:15<span style=\"white-space:pre\">	</span>ETC Teams<br>14:20 - 14:25<span style=\"white-space:pre\">	</span>IPC Teams<br>14:30 - 14:35<span style=\"white-space:pre\">	</span>MPC Teams<br>14:40 - 14:45<span style=\"white-space:pre\">	</span>PTC Teams</p><p><br></p>',1,1667355839),(30,2567,'If you can’t access the Vimeo links, please use\r\nt...','<h4><span class=\"\" style=\"color: rgb(239, 69, 64);\"></span></h4><h5><span class=\"\" style=\"color: rgb(239, 69, 64);\">If you can’t access the Vimeo links, please use\r\nthe videos titled (Box Link).”</span></h5><h4><span class=\"\" style=\"color: rgb(239, 69, 64);\"></span></h4>',1,1669916365),(31,2567,'ADJOURNChina, Malaysia, Singapore &amp; Taiwan 15:...','<p><b>ADJOURN<br></b></p><p>China, Malaysia, Singapore &amp; Taiwan <b>15:30</b><br>India <b>13:00</b><br>Ukraine <b>09:3</b><b>0</b>&nbsp;</p>',1,1670783500),(33,2567,'ADJOURNChina, Malaysia, Singapore &amp; Taiwan 15:...','<p><b>ADJOURN<br></b></p><p>China, Malaysia, Singapore &amp; Taiwan <b>15:30</b><br>India <b>13:00</b><br>Ukraine <b>09:3</b><b>0</b>&nbsp;</p>',1,1670783500),(34,2567,'ADJOURNChina, Malaysia, Singapore &amp; Taiwan 15:...','<p><b>ADJOURN<br></b></p><p>China, Malaysia, Singapore &amp; Taiwan <b>15:30</b><br>India <b>13:00</b><br>Ukraine <b>09:3</b><b>0</b>&nbsp;</p>',1,1670783500),(35,2567,'ADJOURNChina, Malaysia, Singapore &amp; Taiwan 15:...','<p><b>ADJOURN<br></b></p><p>China, Malaysia, Singapore &amp; Taiwan <b>15:15</b><br>India <b>12:45</b><br>Ukraine <b>09:15</b>&nbsp;</p>',1,1670997535),(36,2569,'*Strengths\r\nand Development Areas &amp; Pre-Course...','<p></p><h5><span class=\"\" style=\"color: rgb(239, 69, 64);\">*Strengths\r\nand Development Areas &amp; Pre-Course Assessment: Due January 6th 12:59PM*</span></h5><p></p>',1,1671469295),(37,2571,'If you can’t access the Vimeo links, please use\nt...','<h4><span class=\"\" style=\"color: rgb(239, 69, 64);\"></span></h4><h5><span class=\"\" style=\"color: rgb(239, 69, 64);\">If you can’t access the Vimeo links, please use\nthe videos titled (Box Link).”</span></h5><h4><span class=\"\" style=\"color: rgb(239, 69, 64);\"></span></h4>',1,1669916365);
/*!40000 ALTER TABLE `mdl_label` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:25:02
