-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_grade_settings`
--

DROP TABLE IF EXISTS `mdl_grade_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_grade_settings` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `courseid` bigint(10) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_gradsett_counam_uix` (`courseid`,`name`),
  KEY `mdl_gradsett_cou_ix` (`courseid`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='gradebook settings';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_grade_settings`
--

LOCK TABLES `mdl_grade_settings` WRITE;
/*!40000 ALTER TABLE `mdl_grade_settings` DISABLE KEYS */;
INSERT INTO `mdl_grade_settings` VALUES (1,2,'minmaxtouse','1'),(6,14,'minmaxtouse','1'),(7,25,'minmaxtouse','1'),(12,26,'minmaxtouse','1'),(14,27,'minmaxtouse','1'),(15,28,'minmaxtouse','1'),(16,29,'minmaxtouse','1'),(17,30,'minmaxtouse','1'),(18,31,'minmaxtouse','1'),(19,32,'minmaxtouse','1'),(21,34,'minmaxtouse','1'),(23,38,'minmaxtouse','1'),(24,39,'minmaxtouse','1'),(30,46,'minmaxtouse','1'),(32,52,'minmaxtouse','1'),(33,54,'minmaxtouse','1'),(34,55,'minmaxtouse','1'),(38,60,'minmaxtouse','1'),(39,61,'minmaxtouse','1'),(40,837,'minmaxtouse','1'),(41,838,'minmaxtouse','1'),(42,839,'minmaxtouse','1'),(44,1766,'minmaxtouse','1'),(45,1768,'minmaxtouse','1'),(46,1769,'minmaxtouse','1'),(47,1772,'minmaxtouse','1'),(48,1773,'minmaxtouse','1'),(49,1774,'minmaxtouse','1'),(50,1775,'minmaxtouse','1'),(51,1776,'minmaxtouse','1'),(52,1777,'minmaxtouse','1'),(53,1778,'minmaxtouse','1'),(54,1779,'minmaxtouse','1'),(55,1780,'minmaxtouse','1'),(56,1781,'minmaxtouse','1'),(57,1783,'minmaxtouse','1'),(58,1784,'minmaxtouse','1'),(59,1785,'minmaxtouse','1'),(60,1786,'minmaxtouse','1'),(61,1787,'minmaxtouse','1'),(62,1788,'minmaxtouse','1'),(63,1789,'minmaxtouse','1'),(64,1790,'minmaxtouse','1'),(65,1791,'minmaxtouse','1'),(66,1792,'minmaxtouse','1'),(67,1793,'minmaxtouse','1'),(68,1796,'minmaxtouse','1'),(69,1797,'minmaxtouse','1'),(70,1798,'minmaxtouse','1'),(71,1799,'minmaxtouse','1'),(72,1876,'minmaxtouse','1'),(74,1956,'minmaxtouse','1'),(75,1957,'minmaxtouse','1'),(76,1958,'minmaxtouse','1'),(77,1959,'minmaxtouse','1'),(79,1961,'minmaxtouse','1'),(80,1962,'minmaxtouse','1'),(81,1963,'minmaxtouse','1'),(82,1965,'minmaxtouse','1'),(83,1991,'minmaxtouse','1'),(84,1992,'minmaxtouse','1'),(85,1993,'minmaxtouse','1'),(87,2020,'minmaxtouse','1'),(88,2022,'minmaxtouse','1'),(96,2385,'minmaxtouse','1'),(98,2388,'minmaxtouse','1'),(99,2489,'minmaxtouse','1'),(101,2496,'minmaxtouse','1'),(102,2497,'minmaxtouse','1'),(103,2498,'minmaxtouse','1'),(104,2499,'minmaxtouse','1'),(105,2500,'minmaxtouse','1'),(106,2504,'minmaxtouse','1'),(107,2506,'minmaxtouse','1'),(108,2507,'minmaxtouse','1'),(109,2508,'minmaxtouse','1'),(110,2510,'minmaxtouse','1'),(112,2512,'minmaxtouse','1'),(113,2514,'minmaxtouse','1'),(114,2515,'minmaxtouse','1'),(115,2516,'minmaxtouse','1'),(116,2517,'minmaxtouse','1'),(117,2518,'minmaxtouse','1'),(118,2519,'minmaxtouse','1'),(119,2520,'minmaxtouse','1'),(120,2521,'minmaxtouse','1'),(121,2522,'minmaxtouse','1'),(122,2523,'minmaxtouse','1'),(123,2524,'minmaxtouse','1'),(124,2525,'minmaxtouse','1'),(125,2527,'minmaxtouse','1'),(126,2528,'minmaxtouse','1'),(129,2532,'minmaxtouse','1'),(130,2533,'minmaxtouse','1'),(132,2535,'minmaxtouse','1'),(133,2536,'minmaxtouse','1'),(134,2537,'minmaxtouse','1'),(136,2539,'minmaxtouse','1'),(137,2540,'minmaxtouse','1'),(138,2541,'minmaxtouse','1'),(139,2542,'minmaxtouse','1'),(140,2543,'minmaxtouse','1'),(141,2544,'minmaxtouse','1'),(142,2545,'minmaxtouse','1'),(143,2546,'minmaxtouse','1'),(144,2547,'minmaxtouse','1'),(145,2549,'minmaxtouse','1'),(146,2550,'minmaxtouse','1'),(147,2551,'minmaxtouse','1'),(148,2552,'minmaxtouse','1'),(149,2553,'minmaxtouse','1'),(150,2556,'minmaxtouse','1'),(151,2538,'minmaxtouse','1'),(152,2557,'minmaxtouse','1'),(154,2561,'minmaxtouse','1'),(155,2562,'minmaxtouse','1'),(156,2563,'minmaxtouse','1'),(157,2564,'minmaxtouse','1'),(158,2565,'minmaxtouse','1'),(159,2566,'minmaxtouse','1'),(160,2567,'minmaxtouse','1'),(161,2568,'minmaxtouse','1'),(162,2569,'minmaxtouse','1'),(163,2570,'minmaxtouse','1'),(164,2571,'minmaxtouse','1'),(165,2697,'minmaxtouse','1');
/*!40000 ALTER TABLE `mdl_grade_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:23:57
