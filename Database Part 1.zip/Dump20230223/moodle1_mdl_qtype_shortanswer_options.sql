-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: moodle1
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mdl_qtype_shortanswer_options`
--

DROP TABLE IF EXISTS `mdl_qtype_shortanswer_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mdl_qtype_shortanswer_options` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `questionid` bigint(10) NOT NULL DEFAULT '0',
  `usecase` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mdl_qtypshoropti_que_uix` (`questionid`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED COMMENT='Options for short answer questions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdl_qtype_shortanswer_options`
--

LOCK TABLES `mdl_qtype_shortanswer_options` WRITE;
/*!40000 ALTER TABLE `mdl_qtype_shortanswer_options` DISABLE KEYS */;
INSERT INTO `mdl_qtype_shortanswer_options` VALUES (1,1,0),(7,187,0),(8,218,0),(9,249,0),(10,250,0),(11,281,0),(17,467,0),(18,498,0),(19,529,0),(23,653,0),(24,684,0),(25,715,0),(27,777,0),(28,808,0),(29,839,0),(30,870,0),(31,901,0),(32,932,0),(33,963,0),(34,994,0),(35,1025,0),(36,1056,0),(37,1087,0),(38,1118,0),(39,1149,0),(40,1180,0),(41,1211,0),(42,1242,0),(43,1273,0),(44,1304,0),(45,1335,0),(46,1366,0),(47,1397,0),(48,1428,0),(49,1459,0),(50,1490,0),(51,1521,0),(52,1552,0),(56,1676,0),(60,1800,0),(62,1862,0),(63,1893,0),(64,1924,0),(65,1955,0),(66,1986,0),(67,2017,0),(68,2048,0),(69,2079,0),(71,2141,0),(72,2172,0),(73,2203,0),(74,2234,0),(76,2296,0),(77,2327,0),(80,2420,0),(82,2482,0),(84,2544,0),(85,2575,0),(86,2606,0),(87,2637,0),(88,2668,0),(90,2730,0),(91,2761,0),(92,2792,0),(93,2823,0),(94,2854,0),(96,2947,0),(97,2978,0),(99,3153,0),(100,3241,0),(101,3272,0),(102,3303,0),(103,3334,0),(104,3365,0),(105,3396,0),(106,3427,0),(107,3458,0);
/*!40000 ALTER TABLE `mdl_qtype_shortanswer_options` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-23 17:21:22
